using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GesEmpAspNet.Models
{
    [Table("departements")]
    public class Departement
    {
        [Key]
        public int Id { get; set; }

        // Name est obligatoire et unique
        [Required(ErrorMessage = "Le nom du departement est obligatoire")]
        [StringLength(100,
            MinimumLength = 3,
            ErrorMessage = "Le nom du departement doit avoir entre {2} et {1} caractères")]
        public string Name { get; set; } = string.Empty;

        [Column("create_at")]
        public DateTime CreateAt { get; set; }

        [Column("update_at")]
        public DateTime? UpdateAt { get; set; }

        public bool IsArchived { get; set; }

        // Navigation : un département a plusieurs employés
        public ICollection<Employe> Employes { get; set; } = new List<Employe>();

        public Departement()
        {
            IsArchived = false;
            CreateAt = DateTime.Now;
        }
    }
}
