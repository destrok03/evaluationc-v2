using System.ComponentModel.DataAnnotations;

namespace GesEmpAspNet.Models
{
    public abstract class User
    {
        [Key]
        public int Id { get; set; }
        [EmailAddress]
        public string? Email { get; set; }

        public string? Password { get; set; }    }
}
