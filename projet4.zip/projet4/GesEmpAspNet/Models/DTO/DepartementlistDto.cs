using GesEmpAspNet.Models;

namespace GesEmpAspNet.DTO
{
    public class DepartementListDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public bool IsArchived { get; set; }
        public int NombreEmployes { get; set; }

        public static DepartementListDto FromEntity(Departement d)
        {
            return new DepartementListDto
            {
                Id = d.Id,
                Name = d.Name,
                IsArchived = d.IsArchived,
                NombreEmployes = d.Employes?.Count ?? 0
            };
        }

        public static List<DepartementListDto> FromEntities(IEnumerable<Departement> departements)
        {
            return departements.Select(FromEntity).ToList();
        }
    }
}
