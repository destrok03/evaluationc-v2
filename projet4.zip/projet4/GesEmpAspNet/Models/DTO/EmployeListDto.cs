using GesEmpAspNet.Models;

namespace GesEmpAspNet.DTO
{
    public class EmployeListDto
    {
        public int Id { get; set; }
        public string NomComplet { get; set; } = string.Empty;
        public string Telephone { get; set; } = string.Empty;
        public string Numero { get; set; } = string.Empty;
        public string? Adresse { get; set; }
        public string? DepartementName { get; set; }
        public bool IsArchived { get; set; }
        public DateTime? EmbaucheAt { get; set; }
        public string? Photo { get; set; }

        public static EmployeListDto FromEntity(Employe e)
        {
            return new EmployeListDto
            {
                Id = e.Id,
                NomComplet = e.NomComplet,
                Telephone = e.Telephone,
                Numero = e.Numero,
                Adresse = e.Adresse,
                DepartementName = e.Departement?.Name,
                IsArchived = e.IsArchived,
                EmbaucheAt = e.EmbaucheAt,
                Photo = e.Photo
            };
        }

        public static List<EmployeListDto> FromEntities(IEnumerable<Employe> employes)
        {
            return employes.Select(FromEntity).ToList();
        }
    }
}
