namespace GesEmpAspNet.DTO
{
    public class EmployeSearchFormDto
    {
        public string? Numero { get; set; }
        public int? DepartementId { get; set; }
        public bool? IsArchived { get; set; }
    }
}
