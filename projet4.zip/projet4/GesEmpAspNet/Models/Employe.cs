using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GesEmpAspNet.Models
{
    public class Employe : User
    {
        [Required(ErrorMessage = "Le nom et le prénom de l'employé sont obligatoires")]
        [StringLength(25,
            MinimumLength = 4,
            ErrorMessage = "Le nom et le prénom de l'employé doivent avoir entre {2} et {1} caractères")]
        public string NomComplet { get; set; } = string.Empty;

        [Required(ErrorMessage = "Le téléphone de l'employé est obligatoire")]
        [RegularExpression(@"^(77|78)\d{7}$",
            ErrorMessage = "Le numéro de téléphone n'est pas valide. Il doit contenir 9 chiffres et commencer par 77 ou 78.")]
        [StringLength(25)]
        public string Telephone { get; set; } = string.Empty;

        public string? Adresse { get; set; }

        public DateTime CreateAt { get; set; }

        public DateTime? UpdateAt { get; set; }

        public bool IsArchived { get; set; }

        [StringLength(20)]
        public string Numero { get; set; } = string.Empty;

        [DataType(DataType.Date)]
        public DateTime? EmbaucheAt { get; set; }

        // Nom de l'image
        [StringLength(255)]
        public string? Photo { get; set; }

        // Champ non mappé à la base
        [NotMapped]
        public IFormFile? PhotoFile { get; set; }

        // Clé étrangère vers Departement
        public int DepartementId { get; set; }

        [Required(ErrorMessage = "Le departement de l'employé est obligatoire")]
        public Departement? Departement { get; set; }

        public Employe()
        {
            IsArchived = false;
            CreateAt = DateTime.Now;
        }
    }
}
