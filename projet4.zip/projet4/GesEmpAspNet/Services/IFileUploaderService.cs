using Microsoft.AspNetCore.Http;

namespace GesEmpAspNet.Services
{
    public interface IFileUploaderService
    {
        Task<string> UploadAsync(IFormFile file);
    }
}
