namespace GesEmpAspNet.Services
{
    public interface IGenerateNumeroService
    {
        string GenerateNumeroCompte();
    }
}
