using GesEmpAspNet.Models;

namespace GesEmpAspNet.Services
{
    public interface IDepartementService
    {
        Task<List<Departement>> GetAllAsync();
        Task<Departement?> GetByIdAsync(int id);
        Task<(List<Departement> Items, int TotalCount)> GetPagedAsync(int page, int pageSize);
        Task<Departement> CreateAsync(Departement departement);
        Task<Departement?> UpdateAsync(Departement departement);
        Task<bool> ArchiveAsync(int id);
    }
}
