using GesEmpAspNet.Services;

namespace GesEmpAspNet.Services.Impl
{
    public class GenerateNumeroService : IGenerateNumeroService
    {
        public string GenerateNumeroCompte()
        {
            // Version simple, tu pourras l'améliorer (ex: basé sur le dernier id)
            return $"EMP-{DateTime.Now:yyyyMMddHHmmssfff}";
        }
    }
}
