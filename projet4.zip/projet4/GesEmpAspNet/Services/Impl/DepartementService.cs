using GesEmpAspNet.Data;
using GesEmpAspNet.Models;
using Microsoft.EntityFrameworkCore;

namespace GesEmpAspNet.Services.Impl
{
    public class DepartementService : IDepartementService
    {
        private readonly GesEmpDbContext _context;

        public DepartementService(GesEmpDbContext context)
        {
            _context = context;
        }

        public async Task<List<Departement>> GetAllAsync()
        {
            return await _context.Departements
                .Where(d => !d.IsArchived)
                .ToListAsync();
        }

        public async Task<Departement?> GetByIdAsync(int id)
        {
            return await _context.Departements
                .Include(d => d.Employes)
                .FirstOrDefaultAsync(d => d.Id == id && !d.IsArchived);
        }
 public async Task<(List<Departement> Items, int TotalCount)> GetPagedAsync(int page, int pageSize)
        {
            var query = _context.Departements
                .Include(d => d.Employes)
                .OrderByDescending(d => d.Id);

            var totalCount = await query.CountAsync();

            var items = await query
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return (items, totalCount);
        }
        public async Task<Departement> CreateAsync(Departement departement)
        {
            _context.Departements.Add(departement);
            await _context.SaveChangesAsync();
            return departement;
        }

        public async Task<Departement?> UpdateAsync(Departement departement)
        {
            var existing = await _context.Departements.FindAsync(departement.Id);
            if (existing == null) return null;

            existing.Name = departement.Name;
            existing.UpdateAt = DateTime.Now;

            await _context.SaveChangesAsync();
            return existing;
        }

        public async Task<bool> ArchiveAsync(int id)
        {
            var dep = await _context.Departements.FindAsync(id);
            if (dep == null) return false;

            dep.IsArchived = true;
            dep.UpdateAt = DateTime.Now;
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
