using GesEmpAspNet.Data;
using GesEmpAspNet.Models;
using Microsoft.EntityFrameworkCore;
using GesEmpAspNet.DTO;

namespace GesEmpAspNet.Services.Impl
{
    public class EmployeService : IEmployeService
    {
        private readonly GesEmpDbContext _context;

        public EmployeService(GesEmpDbContext context)
        {
            _context = context;
        }

        public async Task<List<Employe>> GetAllAsync()
        {
            return await _context.Employes
                .Include(e => e.Departement)
                .Where(e => !e.IsArchived)
                .ToListAsync();
        }

        public async Task<Employe?> GetByIdAsync(int id)
        {
            return await _context.Employes
                .Include(e => e.Departement)
                .FirstOrDefaultAsync(e => e.Id == id && !e.IsArchived);
        }
public async Task<(List<Employe> Items, int TotalCount)> SearchAsync(
            EmployeSearchFormDto filter,
            int? defaultDepartementId,
            int page,
            int pageSize
        )
        {
            var query = _context.Employes
                .Include(e => e.Departement)
                .AsQueryable();

            // isArchived : false par défaut si non spécifié
            var isArchived = filter.IsArchived ?? false;
            query = query.Where(e => e.IsArchived == isArchived);

            // Département : soit celui du filtre, soit celui passé dans l'URL (idDept)
            var deptId = filter.DepartementId ?? defaultDepartementId;
            if (deptId.HasValue)
            {
                query = query.Where(e => e.DepartementId == deptId.Value);
            }

            // Numero
            if (!string.IsNullOrWhiteSpace(filter.Numero))
            {
                query = query.Where(e => e.Numero == filter.Numero);
            }

            var totalCount = await query.CountAsync();

            var items = await query
                .OrderByDescending(e => e.Id)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return (items, totalCount);
        }
        public async Task<Employe> CreateAsync(Employe employe)
        {
            _context.Employes.Add(employe);
            await _context.SaveChangesAsync();
            return employe;
        }

        public async Task<Employe?> UpdateAsync(Employe employe)
        {
            var existing = await _context.Employes.FindAsync(employe.Id);
            if (existing == null) return null;

            existing.NomComplet = employe.NomComplet;
            existing.Telephone = employe.Telephone;
            existing.Adresse = employe.Adresse;
            existing.Numero = employe.Numero;
            existing.EmbaucheAt = employe.EmbaucheAt;
            existing.DepartementId = employe.DepartementId;
            existing.UpdateAt = DateTime.Now;

            await _context.SaveChangesAsync();
            return existing;
        }

        public async Task<bool> ArchiveAsync(int id)
        {
            var emp = await _context.Employes.FindAsync(id);
            if (emp == null) return false;

            emp.IsArchived = true;
            emp.UpdateAt = DateTime.Now;
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
