using GesEmpAspNet.Services;
using Microsoft.AspNetCore.Hosting;

namespace GesEmpAspNet.Services.Impl
{
    public class FileUploaderService : IFileUploaderService
    {
        private readonly IWebHostEnvironment _env;

        public FileUploaderService(IWebHostEnvironment env)
        {
            _env = env;
        }

        public async Task<string> UploadAsync(IFormFile file)
        {
            var uploadsFolder = Path.Combine(_env.WebRootPath, "uploads", "employes");
            Directory.CreateDirectory(uploadsFolder);

            var uniqueName = $"{Guid.NewGuid()}{Path.GetExtension(file.FileName)}";
            var filePath = Path.Combine(uploadsFolder, uniqueName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            return uniqueName;
        }
    }
}
