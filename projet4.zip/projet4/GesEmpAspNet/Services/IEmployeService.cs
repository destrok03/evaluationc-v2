using GesEmpAspNet.Models;
using GesEmpAspNet.DTO;

namespace GesEmpAspNet.Services
{
    public interface IEmployeService
    {
        Task<List<Employe>> GetAllAsync();
        Task<Employe?> GetByIdAsync(int id);
        Task<(List<Employe> Items, int TotalCount)> SearchAsync(
            EmployeSearchFormDto filter,
            int? defaultDepartementId,
            int page,
            int pageSize
        );

        Task<Employe> CreateAsync(Employe employe);
        Task<Employe?> UpdateAsync(Employe employe);
        Task<bool> ArchiveAsync(int id);
    }
}
