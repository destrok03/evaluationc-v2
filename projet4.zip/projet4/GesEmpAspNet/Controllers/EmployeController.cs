using GesEmpAspNet.DTO;
using GesEmpAspNet.Services;
using GesEmpAspNet.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace GesEmpAspNet.Controllers
{
    [Route("employe")]
    public class EmployeController : Controller
    {
        private readonly IEmployeService _employeService;
        private readonly IDepartementService _departementService;
        private readonly IGenerateNumeroService _numService;
        private readonly IFileUploaderService _fileUploader;
        private readonly IConfiguration _configuration;

        private int LimitParPage => _configuration.GetValue<int>("LimitParPage", 5);

        public EmployeController(
            IEmployeService employeService,
            IDepartementService departementService,
            IGenerateNumeroService numService,
            IFileUploaderService fileUploader,
            IConfiguration configuration)
        {
            _employeService = employeService;
            _departementService = departementService;
            _numService = numService;
            _fileUploader = fileUploader;
            _configuration = configuration;
        }

        /*
            Symfony:
            #[Route('/employe/list/{idDept?}', methods:["GET","POST"])]
        */

        [HttpGet("list/{idDept?}")]
        public async Task<IActionResult> List(int? idDept, [FromQuery] EmployeSearchFormDto search, int page = 1)
        {
            // Récupération du département (optionnel)
            DTO.DepartementListDto? departementDto = null;
            if (idDept.HasValue)
            {
                var departement = await _departementService.GetByIdAsync(idDept.Value);
                if (departement != null)
                {
                    departementDto = DTO.DepartementListDto.FromEntity(departement);
                }
            }

            // Recherche + pagination
            var (items, totalCount) = await _employeService.SearchAsync(
                search,
                idDept,
                page,
                LimitParPage
            );

            var vm = new EmployeListViewModel
            {
                Employes = EmployeListDto.FromEntities(items),
                Departement = departementDto,
                PageEncours = page,
                NbrePage = (int)Math.Ceiling(totalCount / (double)LimitParPage),
                Search = search
            };

            return View(vm);
        }


        /*
            Symfony:
            #[Route('/employe/add', methods:["GET","POST"])]
        */

        [HttpGet("add")]
        public IActionResult Add()
        {
            var vm = new EmployeFormViewModel
            {
                Employe = new Models.Employe
                {
                    Numero = _numService.GenerateNumeroCompte()
                }
            };

            return View(vm);
        }

        [HttpPost("add")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(EmployeFormViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var employe = model.Employe;

            // Adresse : "Rue: X - Ville: Y - Pays: Z"
            employe.Adresse = $"Rue: {model.Rue} - Ville: {model.Ville} - Pays: {model.Pays}";

            // Photo
            if (employe.PhotoFile != null)
            {
                var photoName = await _fileUploader.UploadAsync(employe.PhotoFile);
                employe.Photo = photoName;
            }

            // Email
            if (!string.IsNullOrWhiteSpace(employe.NomComplet))
            {
                var emailBase = employe.NomComplet.Replace(" ", ".").ToLower();
                employe.Email = $"{emailBase}@example.com";
            }

            // Password par défaut
            employe.Password = "password123";

            await _employeService.CreateAsync(employe);

            TempData["success"] = "Employé ajouté avec succès";
            return RedirectToAction("List");
        }
    }
}
