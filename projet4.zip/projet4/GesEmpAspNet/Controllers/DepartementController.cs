using GesEmpAspNet.DTO;
using GesEmpAspNet.Models;
using GesEmpAspNet.Services;
using GesEmpAspNet.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace GesEmpAspNet.Controllers
{
    [Route("departement")]
    public class DepartementController : Controller
    {
        private readonly IDepartementService _departementService;
        private readonly IConfiguration _configuration;

        private int LimitParPage => _configuration.GetValue<int>("LimitParPage", 5);

        public DepartementController(IDepartementService departementService, IConfiguration configuration)
        {
            _departementService = departementService;
            _configuration = configuration;
        }

[HttpPost]
    public async Task<IActionResult> Create(DepartementCreateViewModel model)
    {
        if (!ModelState.IsValid || string.IsNullOrWhiteSpace(model.Name))
        {
            TempData["error"] = "Le nom du département est obligatoire.";
            return RedirectToAction("List");
        }

        var departement = new Departement
        {
        Name = model.Name,
        CreateAt = DateTime.UtcNow,
        IsArchived = false
    };


        await _departementService.CreateAsync(departement);

        TempData["success"] = "Département ajouté avec succès.";
        return RedirectToAction("List");
    }        // GET /departement/list?page=1
        [HttpGet("list")]
        public async Task<IActionResult> List(int page = 1)
        {
            var (items, totalCount) = await _departementService.GetPagedAsync(page, LimitParPage);

            var vm = new DepartementListViewModel
            {
                Departements = DepartementListDto.FromEntities(items),
                PageEncours = page,
                NbrePage = (int)Math.Ceiling(totalCount / (double)LimitParPage),
                NewDepartement = new Departement()
            };

            return View(vm);
        }

        // POST /departement/list
        [HttpPost("list")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> List(DepartementListViewModel model, int page = 1)
        {
            if (ModelState.IsValid)
            {
                await _departementService.CreateAsync(model.NewDepartement);
                TempData["success"] = "Département ajouté avec succès";
                return RedirectToAction(nameof(List));
            }

            // Si erreurs de validation : recharger la liste + pagination
            var (items, totalCount) = await _departementService.GetPagedAsync(page, LimitParPage);
            model.Departements = DepartementListDto.FromEntities(items);
            model.PageEncours = page;
            model.NbrePage = (int)Math.Ceiling(totalCount / (double)LimitParPage);

            return View(model);
        }
    }
}
