using GesEmpAspNet.Data;
using GesEmpAspNet.Services;
using GesEmpAspNet.Services.Impl;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// ========== DB CONTEXT ==========
builder.Services.AddDbContext<GesEmpDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

// ========== SERVICES (DI) ==========
builder.Services.AddScoped<IDepartementService, DepartementService>();
builder.Services.AddScoped<IEmployeService, EmployeService>();
builder.Services.AddScoped<IDepartementService, DepartementService>();
builder.Services.AddScoped<IGenerateNumeroService, GenerateNumeroService>();
builder.Services.AddScoped<IFileUploaderService, FileUploaderService>();


// MVC
builder.Services.AddControllersWithViews();

var app = builder.Build();

// ========== PIPELINE HTTP ==========
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseAuthorization();

// Route par défaut
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();

