using System.ComponentModel.DataAnnotations;
using GesEmpAspNet.Models;
using Microsoft.AspNetCore.Http;

namespace GesEmpAspNet.ViewModels
{
    public class EmployeFormViewModel
    {
        public Employe Employe { get; set; } = new Employe();

        // Champs "non mappés" du formulaire Symfony
        [Required(ErrorMessage = "Le pays est obligatoire")]
        public string Pays { get; set; } = string.Empty;

        [Required(ErrorMessage = "La ville est obligatoire")]
        public string Ville { get; set; } = string.Empty;

        [Required(ErrorMessage = "La rue est obligatoire")]
        public string Rue { get; set; } = string.Empty;
    }
}
