using System.Collections.Generic;

namespace GesEmpAspNet.ViewModels
{
    public class PaginationViewModel
    {
        public int NbrePage { get; set; }
        public int PageEncours { get; set; }

        // Action à appeler (ex: "List")
        public string ActionName { get; set; } = string.Empty;

        // Optionnel : si tu veux préciser le controller (sinon la vue actuelle)
        public string? ControllerName { get; set; }

        // Pour garder les filtres dans l'URL (numero, departementId, isArchived, etc.)
        public IDictionary<string, string?> QueryParams { get; set; }
            = new Dictionary<string, string?>();
    }
}
