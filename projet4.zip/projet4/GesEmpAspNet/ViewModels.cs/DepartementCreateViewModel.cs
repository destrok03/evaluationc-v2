namespace GesEmpAspNet.ViewModels
{
    public class DepartementCreateViewModel
    {
        public string Name { get; set; } = string.Empty;
    }
}
