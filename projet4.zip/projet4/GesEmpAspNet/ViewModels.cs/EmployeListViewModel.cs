using GesEmpAspNet.DTO;

namespace GesEmpAspNet.ViewModels
{
    public class EmployeListViewModel
{
    public List<EmployeListDto> Employes { get; set; } = new();
    public DepartementListDto? Departement { get; set; }
    public int NbrePage { get; set; }
    public int PageEncours { get; set; }
    public EmployeSearchFormDto Search { get; set; } = new();
}

}
