using GesEmpAspNet.DTO;
using GesEmpAspNet.Models;
using System.Collections.Generic;

namespace GesEmpAspNet.ViewModels
{
    public class DepartementListViewModel
{
    public List<DepartementListDto> Departements { get; set; } = new();
    public int NbrePage { get; set; }
    public int PageEncours { get; set; }
    public Departement NewDepartement { get; set; } = new Departement();
}

}
