using GesEmpAspNet.Models;
using Microsoft.EntityFrameworkCore;

namespace GesEmpAspNet.Data
{
    public class GesEmpDbContext : DbContext
    {
        public GesEmpDbContext(DbContextOptions<GesEmpDbContext> options)
            : base(options)
        {
        }

        public DbSet<Departement> Departements { get; set; } = null!;
        public DbSet<Employe> Employes { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // === Departement ===
            modelBuilder.Entity<Departement>(entity =>
            {
                entity.ToTable("departements");

                entity.HasKey(d => d.Id);

                entity.Property(d => d.Name)
                      .IsRequired()
                      .HasMaxLength(100);

                // Unique sur le nom
                entity.HasIndex(d => d.Name)
                      .IsUnique();

                entity.Property(d => d.CreateAt)
                      .HasColumnName("create_at");

                entity.Property(d => d.UpdateAt)
                      .HasColumnName("update_at");
            });

            // === Employe ===
            modelBuilder.Entity<Employe>(entity =>
            {
                entity.ToTable("employes"); // adapte au vrai nom de ta table si besoin

                // Unique sur Telephone
                entity.HasIndex(e => e.Telephone)
                      .IsUnique();

                // Unique sur Numero
                entity.HasIndex(e => e.Numero)
                      .IsUnique();

                entity.Property(e => e.NomComplet)
                      .IsRequired()
                      .HasMaxLength(25);

                entity.Property(e => e.Telephone)
                      .IsRequired()
                      .HasMaxLength(25);

                entity.Property(e => e.Numero)
                      .HasMaxLength(20);

                entity.Property(e => e.Photo)
                      .HasMaxLength(255);

                // Relation Many-to-One : Employe → Departement
                entity.HasOne(e => e.Departement)
                      .WithMany(d => d.Employes)
                      .HasForeignKey(e => e.DepartementId)
                      .OnDelete(DeleteBehavior.Restrict);
            });
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // Si tu configures déjà le DbContext dans Program.cs, on laisse vide.
            // C'est juste au cas où quelqu'un instancie le contexte sans passer par DI.
            if (!optionsBuilder.IsConfigured)
            {
                // Exemple : optionsBuilder.UseSqlServer("name=DefaultConnection");
            }
        }
    }
}
